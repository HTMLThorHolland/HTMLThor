
/* Important function that submits the singleUploadForm when the user selects a file. */
function uploadJSP() {
	console.log("uploadingFile");
	document.getElementById("singleUploadForm").submit();
}