
/* When a single file is uploaded this function hides the dropdown menu for changing files. */
function hideChangeFile() {
	$('.selectFile').hide();
}